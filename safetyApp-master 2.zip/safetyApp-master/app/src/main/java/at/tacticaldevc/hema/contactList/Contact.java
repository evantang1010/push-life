package at.tacticaldevc.hema.contactList;

public class Contact {

    public String name, number, groupID;
    public Contact(String name, String number, String groupID)
    {
        this.name = name;
        this.number = number;
        this.groupID = groupID;
    }
}
